<?php

$cnn = new mysqli("localhost","root","","cine");

?>