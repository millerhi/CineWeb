-- MySQL dump 10.12
--
-- Host: localhost    Database: cine
-- ------------------------------------------------------
-- Server version	6.0.0-alpha-community-nt-debug

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `cine`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `cine` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `cine`;

--
-- Table structure for table `actor`
--

DROP TABLE IF EXISTS `actor`;
CREATE TABLE `actor` (
  `codigoactor` char(5) NOT NULL,
  `nombre` char(40) NOT NULL,
  `estado` char(1) NOT NULL,
  PRIMARY KEY (`codigoactor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `actor`
--

LOCK TABLES `actor` WRITE;
/*!40000 ALTER TABLE `actor` DISABLE KEYS */;
INSERT INTO `actor` VALUES ('00204','paola aristizabal','V'),('00326','esteban el gei','F'),('02011','juan pablo ariaz','F'),('06087','Stephen Sommers','V'),('14157','tom cruise','V'),('33988','al pacino','V'),('55887','robert de niro','V');
/*!40000 ALTER TABLE `actor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actorpelicula`
--

DROP TABLE IF EXISTS `actorpelicula`;
CREATE TABLE `actorpelicula` (
  `codigoactor` char(5) NOT NULL,
  `idpelicula` int(5) unsigned zerofill NOT NULL,
  `estado` char(1) NOT NULL,
  `id` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `codigoactor` (`codigoactor`),
  KEY `idpelicula` (`idpelicula`),
  CONSTRAINT `actorpelicula_ibfk_1` FOREIGN KEY (`codigoactor`) REFERENCES `actor` (`codigoactor`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `actorpelicula_ibfk_2` FOREIGN KEY (`idpelicula`) REFERENCES `pelicula` (`idpelicula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `actorpelicula`
--

LOCK TABLES `actorpelicula` WRITE;
/*!40000 ALTER TABLE `actorpelicula` DISABLE KEYS */;
INSERT INTO `actorpelicula` VALUES ('00204',00002,'F',00001),('00204',00005,'F',00002),('00204',00004,'F',00003),('14157',00008,'V',00004),('06087',00009,'V',00005),('14157',00010,'V',00006),('06087',00007,'V',00007),('33988',00009,'V',00008),('55887',00005,'V',00009),('14157',00005,'V',00010);
/*!40000 ALTER TABLE `actorpelicula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `director`
--

DROP TABLE IF EXISTS `director`;
CREATE TABLE `director` (
  `codigodirector` char(10) NOT NULL,
  `nombre` char(40) NOT NULL,
  `estado` char(1) NOT NULL,
  PRIMARY KEY (`codigodirector`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `director`
--

LOCK TABLES `director` WRITE;
/*!40000 ALTER TABLE `director` DISABLE KEYS */;
INSERT INTO `director` VALUES ('','','F'),('06050','esteban muÃƒÆ’Ã‚Â±oz','F'),('10145','john carpenter','V'),('11111','ang lee','V'),('20201','sam raimy','V'),('46791','federico fellini','V'),('72921','woody allen','V');
/*!40000 ALTER TABLE `director` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directorpelicula`
--

DROP TABLE IF EXISTS `directorpelicula`;
CREATE TABLE `directorpelicula` (
  `codigodirector` char(10) NOT NULL,
  `idpelicula` int(5) unsigned zerofill NOT NULL,
  `estado` char(1) NOT NULL,
  `id` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `codigodirector` (`codigodirector`),
  KEY `idpelicula` (`idpelicula`),
  CONSTRAINT `directorpelicula_ibfk_1` FOREIGN KEY (`codigodirector`) REFERENCES `director` (`codigodirector`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `directorpelicula_ibfk_2` FOREIGN KEY (`idpelicula`) REFERENCES `pelicula` (`idpelicula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `directorpelicula`
--

LOCK TABLES `directorpelicula` WRITE;
/*!40000 ALTER TABLE `directorpelicula` DISABLE KEYS */;
INSERT INTO `directorpelicula` VALUES ('20201',00007,'V',00001),('10145',00010,'V',00002),('11111',00008,'V',00003),('10145',00005,'V',00004),('11111',00005,'V',00005),('46791',00009,'V',00006);
/*!40000 ALTER TABLE `directorpelicula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genero`
--

DROP TABLE IF EXISTS `genero`;
CREATE TABLE `genero` (
  `codigogenero` char(10) NOT NULL,
  `nombre` char(40) NOT NULL,
  `estado` char(1) NOT NULL,
  PRIMARY KEY (`codigogenero`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `genero`
--

LOCK TABLES `genero` WRITE;
/*!40000 ALTER TABLE `genero` DISABLE KEYS */;
INSERT INTO `genero` VALUES ('11111','accion','V'),('22222','drama','V'),('33333','terror','V'),('44444','infantil','V'),('55555','aventura','V'),('66666','ciencia ficciÃƒÂ³n','V');
/*!40000 ALTER TABLE `genero` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generopelicula`
--

DROP TABLE IF EXISTS `generopelicula`;
CREATE TABLE `generopelicula` (
  `codigogenero` char(10) NOT NULL,
  `idpelicula` int(5) unsigned zerofill NOT NULL,
  `estado` char(1) NOT NULL,
  `id` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `codigogenero` (`codigogenero`),
  KEY `idpelicula` (`idpelicula`),
  CONSTRAINT `generopelicula_ibfk_1` FOREIGN KEY (`codigogenero`) REFERENCES `genero` (`codigogenero`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `generopelicula_ibfk_2` FOREIGN KEY (`idpelicula`) REFERENCES `pelicula` (`idpelicula`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `generopelicula`
--

LOCK TABLES `generopelicula` WRITE;
/*!40000 ALTER TABLE `generopelicula` DISABLE KEYS */;
INSERT INTO `generopelicula` VALUES ('11111',00009,'V',00001),('22222',00005,'V',00002),('33333',00007,'V',00003),('22222',00008,'V',00004),('44444',00010,'V',00005);
/*!40000 ALTER TABLE `generopelicula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `idMenu` char(3) NOT NULL,
  `nombreMenu` char(50) NOT NULL,
  PRIMARY KEY (`idMenu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES ('001','Actor'),('002','Director'),('003','Genero'),('004','Pelicula'),('005','Actorpelicula'),('006','Directorpelicula'),('007','Generopelicula'),('008','Usuario'),('009','Session');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelicula`
--

DROP TABLE IF EXISTS `pelicula`;
CREATE TABLE `pelicula` (
  `idpelicula` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `titulooriginal` char(60) NOT NULL,
  `titulolatino` char(60) NOT NULL,
  `resena` varchar(400) NOT NULL,
  `imagen` char(100) NOT NULL,
  `tipo` char(10) NOT NULL,
  `tamano` int(11) NOT NULL,
  `publicacion` year(4) NOT NULL,
  `estado` char(1) NOT NULL,
  PRIMARY KEY (`idpelicula`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelicula`
--

LOCK TABLES `pelicula` WRITE;
/*!40000 ALTER TABLE `pelicula` DISABLE KEYS */;
INSERT INTO `pelicula` VALUES (00001,'la mejor historia','','As Shakespeare once said in The Tempest, ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“whatÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢s past is prologue,ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â which has never been truer that it is now. Far from an examination of no-longer relevant events, the study of history is the elucidation of everything that has made every one of us who and what we are, and only by understanding wh','../pelicula/Captura de pantalla (5).png','',0,2020,'F'),(00002,'Rebecca','','Una joven reciÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©n casada llega a la imponente propiedad de su nuevo marido, ubicada en la costa inglesa. Y pronto se encuentra batallando con la sombra de su primera esposa, Rebecca, cuyo legado vive en la casa por mucho tiempo despuÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©s de su muerte.','../pelicula/rebecca.jpg','',0,2020,'F'),(00003,'AhÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­ te encargo','','Alex, un creativo de publicidad quiere ser un padre a cualquier costo, pero su esposa es una abogada que estÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ muy concentrada en su carrera, y ser una madre no forma parte de sus planes. Entonces un huÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©sped inesperado pondrÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ a prueba su amor.','../pelicula/ahi-te-encargo.jpg','',0,2020,'F'),(00004,'La caja negra','','Un padre soltero estÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ luchando por recuperar su memoria despuÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©s de sobrevivir un trÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡gico accidente de auto. Desesperado para regresar a su yo anterior mientras intenta criar a su hija, recibe un tratamiento experimental que lo ayuda a sondear su pasado, el cual repentinamente se siente demasiado oscuro como para ser el suyo.','../pelicula/black-box.jpg','',0,2020,'F'),(00005,'Clouds','cielo','Zach Sobiech de 17 anos es un divertido estudiante con talento musical nato Pero pocas semanas despuÃƒÆ’Ã‚Â©s de iniciar su ultimo ano su mundo se viene abajo cuando descubre que su cancer se extendio dejÃƒÆ’Ã‚Â¡ndolo con apenas unos meses de vida Con el limitado tiempo que le queda el y su mejor amiga y companera escritora Sammy deciden seguir sus suenos y finalmente lanzar un album','../pelicula/clouds.jpg','image/jpeg',71038,2020,'V'),(00006,'','','','../pelicula/','',0,0000,'F'),(00007,'The Devils Dolls',' La muÃƒÆ’Ã‚Â±eca vudu','Luego de la caza de un asesino en serie una antigua maldiciÃƒÆ’Ã‚Â³n consume a una ciudad causando una serie de asesinatos brutales y poniendo a un detective contra reloj para salvar la vida de su hija','../pelicula/la-muneca-vudu.jpg','image/jpeg',95634,2019,'V'),(00008,'the mummy','la momia','En una profunda tumba debajo del abrasador desierto una antigua princesa es despertada trayendo toda la maldad y el terror que fueron creciendo durante los milenios y que desafian toda comprension humana','../pelicula/la-momia.jpg','image/jpeg',97935,2017,'V'),(00009,'Nueva York sin salida',' Manhattan sin salida castellano','Durante la busqueda de un duo de asesinos de policias el detective Andre Davis comienza a descubrir una masiva e inesperada conspiracion y debe decidir a quien persigue y quien lo estÃƒÆ’Ã‚Â¡ persiguiendo a el','../pelicula/nueva-york-sin-salida-4k.jpg','image/jpeg',85480,2019,'V'),(00010,'Ben 10 Versus el Universo','Ben 10 contra el Universo','Uno de los villanos mas temibles de la galaxia tiene la intencion de acabar con la humanidad Asi que Ben 10 tendra que viajar al espacio exterior donde se vera en la necesidad de luchar contra el convirtiendose en la batalla mas importante y grande de su vida','../pelicula/ben-10-versus-the-universe.jpg','image/jpeg',61723,2020,'V');
/*!40000 ALTER TABLE `pelicula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submenu`
--

DROP TABLE IF EXISTS `submenu`;
CREATE TABLE `submenu` (
  `idSubmenu` char(3) NOT NULL,
  `nombreSubMenu` char(50) NOT NULL,
  `idMenu` char(3) NOT NULL,
  `url` char(100) NOT NULL,
  PRIMARY KEY (`idSubmenu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submenu`
--

LOCK TABLES `submenu` WRITE;
/*!40000 ALTER TABLE `submenu` DISABLE KEYS */;
INSERT INTO `submenu` VALUES ('001','Control de Actorres','001','../control/facade.php?opc=3'),('002','Control de directores','002','../control/facade.php?opc=23'),('003','Control de generos','003','../control/facade.php?opc=43'),('004','Control de pelicula','004','../control/facade.php?opc=63'),('005','Control de actor y peliculas','005','../control/facade.php?opc=83'),('006','Control de directore y pelicula','006','../control/facade.php?opc=103'),('007','Control de genero y pelicula','007','../control/facade.php?opc=123'),('008','Control de usuario','008','../control/facade.php?opc=143'),('009','Cerrar Sesion','009','../control/cerrar.php');
/*!40000 ALTER TABLE `submenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `usuario` char(20) NOT NULL,
  `clave` char(40) NOT NULL,
  `estado` char(1) NOT NULL,
  PRIMARY KEY (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES ('12345678','juan munoz','F'),('123456789','0f9fa6386aa364e4e8c8dde8c92735e48da127c0','V'),('19082020','6cb4e10720eb5e2e9af169bb0865f8845604a261','V'),('juanpablo','7c7c82cb00d033332d9441890b366d2108665532','V');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-02 15:38:49
