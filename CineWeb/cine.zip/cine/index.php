<!DOCTYPE html>
<html>
<head>
	<title>Cartelera</title>
</head>
<body>
	<?php 

		echo "<script type='text/javascript'> window.location.href='control/facade.php?opc=67';</script>";
	?>
</body>
</html>