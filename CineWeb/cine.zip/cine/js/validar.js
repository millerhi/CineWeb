function validaractor() {

	var codigoactor = document.getElementById("codigoactor").value;
	var nombre = document.getElementById("nombre").value;


	if (!(/^[0-9]{5}$/.test(codigoactor))) {


		alert("Código Incorrecto");
		return false;
	}
	else if (!(/^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]{7,40}$/.test(nombre))) {

		alert("Nombre Incorrecto");
		return false;
	}
	else {
		return true;
	}
}

function validargenero() {

	var codigogenero = document.getElementById("codigogenero").value;
	var nombre = document.getElementById("nombre").value;

	if (!(/^[0-9]{10}$/.test(codigogenero))) {

		alert("Código Incorrecto");
		return false;
	} 
	else if (!(/^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]{7,40}$/.test(nombre))) {

		alert("Nombre Incorrecto");
		return false;
	}
	else {
		 return true;
	}
}

function validardirector () {


	var  codigodirector = document.getElementById("codigodirector").value;
	var nombre = document.getElemntById("nombre").value;


	if (!(/^[0-9]{10}$/.test(codigodirector))) {

		alert("Código Incorrecto");
		return false;
	}
	else if (!(/^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]{7,40}$/.test(nombre))) {

		alert("Nombre Incorrecto");
		return false;
	}
	else {
		return true;
	}


}

function validarpelicula () {

	var titulooriginal = document.getElementById("titulooriginal").value;
	var titulolatino = document.getElementById("titulolatino").value;
	var resena = document.getElementById("resena").value;
	var publicacion = document.getElementById("publicacion").value;

	if(!(/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]{5,60}$/.test(titulooriginal))) {

		alert("El Título original es Incorrecto");
		return false;
	}
	else if (!(/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]{5,60}$/.test(titulolatino))) {

		alert("El Título latino es Incorrecto");
		return false;
	}
	else if (!(/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ , . ]{15,800}$/.test(resena))) {

		alert(" La Reseña es Incorrecta");
		return false;
	}
	else if (!(/^[0-9]{4}$/.test(publicacion))) { 
       
       alert("El Año de publicación Incorrecta");
       return false;
	}
	else {

		return true;
	}

}

function validarusuario () {

	var usuario = document.getElementById("usuario").value;
	var clave = document.getElementById("clave").value;
	var confirmacion = document.getElementById("confirmacion").value;

	if (!(/^[a-zA-ZñÑáéíóúÁÉÍÓÚ]{3,40}$/.test(usuario))) {

		alert("El usuario no es válido");
		return false;
	}
	else if (!(/^[0-9]{8,40}$/.test(clave))) {

		alert("La clave no es válida");
		return false;
	}
	else if (!(/^[0-9]{8,40}$/.test(confirmacion))) {

		alert ("La confirmación no es válida");
		return false;
	} 
	else if (clave != confirmación){

		alert ('Clave y Confirmación Incorrecta');
		return false;
	}
	 else {

	 	 return true;
	 }
}
