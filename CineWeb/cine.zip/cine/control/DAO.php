<?php

class Actor {
	
	var $codigoactor;
	var $nombre;


	function Actor ($_codigoactor, $_nombre) {


		$this -> codigoactor = $_codigoactor;
		$this -> nombre = $_nombre;
	}

	public static function insertar ($_codigoactor, $_nombre)
	{
		include ("../conexion/conexion.php");


		$sql = mysqli_query($cnn, "select codigoactor from actor where codigoactor = '$_codigoactor' and estado = 'V' ");

		$rows = mysqli_num_rows($sql);
		if ($rows== 0) {

			$sql = mysqli_query($cnn, "insert into actor ( codigoactor, nombre, estado) values ('$_codigoactor', '$_nombre', 'V')");
            echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=3' </script>";

		}
		else {

			echo "<script type='text/javascript'> alert('No existe el registro'); history.back(); </script>";
		}
	}
	public static function listar ($_opc, $_campo, $_valor) {

		//matriz para recolectar los datos de la BD segun la consulta
 
		include ("../conexion/conexion.php");
		$matriz = array();

		if($_opc == 3) {
		$query = "select codigoactor, nombre from actor where estado = 'V' order by nombre";

	   }
	   else if ($_opc == 5) {

	   	 $query = "select codigoactor, nombre from actor where estado = 'V' and codigoactor = '$_valor' ";
	   } 

	   else if ($_opc == 7) {

				$query = "select actor.codigoactor, actor.nombre from actor inner join actorpelicula on actor.codigoactor = actorpelicula.codigoactor inner join pelicula on actorpelicula.idpelicula  = pelicula.idpelicula where pelicula.idpelicula = '$_valor';";

			}


	   $sql = mysqli_query ($cnn, $query);
	   $rows = mysqli_num_rows ($sql);

	   for($i = 0; $i < $rows; $i++) {

	   	$dato = mysqli_fetch_array($sql);

	   	array_push ($matriz, Actor :: mostrar($dato));
	   }
	   return $matriz;

	}

	public static function mostrar($dato) {

		$_codigoactor = $dato ["codigoactor"];
		$_nombre = $dato ["nombre"];
		$actor = new Actor ($_codigoactor, $_nombre);

		return $actor;
	}

	public static function eliminar($_codigoactor){

 include ("../conexion/conexion.php");

 $sql = mysqli_query($cnn, "update actor set estado = 'F' where codigoactor = '$_codigoactor'");

 $rows = mysqli_affected_rows($cnn);

 if ($rows == 0 ) {

 	echo "<script type='text/javascript'> alert('No se eliminó el Registro'); history.back(); </script>";
 }
 else {

 	echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=3'; </script>";
 }
}

public static function modificar ($_codigoactor, $_nombre) {

	include ("../conexion/conexion.php");
	$sql = mysqli_query($cnn, "update actor set nombre = '$_nombre' where codigoactor = '$_codigoactor' ");

	$rows = mysqli_affected_rows($cnn);

	if($rows == 0) {

		echo "<script type= 'text/javascript'> alert ('No se puede modificar el registro'); history.back(); </script>";
	}
	else {

		echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=3'; </script>";
	}
}
}


class Director {

	var $codigodirector;
	var $nombre;

	function Director ($_codigodirector, $_nombre) {

		$this -> codigodirector = $_codigodirector;
		$this -> nombre = $_nombre;
	}

	public static function insertar ($_codigodirector, $_nombre) 
	{

		include ("../conexion/conexion.php");

		$sql = mysqli_query($cnn, "select codigodirector from director where codigodirector = '$_codigodirector' and estado = 'V' ");

		$rows = mysqli_num_rows($sql);
		if ($rows == 0) {

			$sql = mysqli_query($cnn, "insert into director ( codigodirector, nombre, estado ) values ('$_codigodirector', '$_nombre', 'V')");

			echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=23' </script>";
		}
		else {

			echo  "<script type='text/javascript'> alert ('No existe el registro'); history.back(); </script>";
		}

		}

		public static function listar ($_opc, $_campo, $_valor) {

			include("../conexion/conexion.php");
			$matriz = array();

			if($_opc == 23) {

				$query = "select codigodirector, nombre from director where estado = 'V' order by nombre";

			}
			else if ($_opc == 25) {

				$query = "select codigodirector, nombre from director where estado = 'V' and codigodirector = '$_valor'";
			}
			else if ($_opc == 27) {

				$query = "select director.codigodirector, director.nombre from director inner join directorpelicula on director.codigodirector = directorpelicula.codigodirector inner join pelicula on directorpelicula.idpelicula = pelicula.idpelicula where pelicula.idpelicula = '$_valor';";
			}

			$sql = mysqli_query($cnn, $query);
			$rows = mysqli_num_rows($sql);

			for($i = 0; $i < $rows; $i++) {   

				$dato = mysqli_fetch_array($sql);

				array_push($matriz, Director :: mostrar($dato));
			}
			return $matriz;
		}

		public static function mostrar($dato) {

		$_codigodirector = $dato ["codigodirector"];
		$_nombre = $dato ["nombre"];
		$director = new Director ($_codigodirector, $_nombre);

		return $director;
	}

	public static function eliminar($_codigodirector){

 include ("../conexion/conexion.php");

 $sql = mysqli_query($cnn, "update director set estado = 'F' where codigodirector = '$_codigodirector'");

 $rows = mysqli_affected_rows($cnn);

 if ($rows == 0 ) {

 	echo "<script type='text/javascript'> alert('No se eliminó el Registro'); history.back(); </script>";
 }
 else {

 	echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=23'; </script>";
 }
}

 public static function modificar ($_codigodirector, $_nombre) {

	include ("../conexion/conexion.php");
	$sql = mysqli_query($cnn, "update director set nombre = '$_nombre' where codigodirector = '$_codigodirector' ");

	$rows = mysqli_affected_rows($cnn);

	if($rows == 0) {

		echo "<script type= 'text/javascript'> alert ('No se puede modificar el registro'); history.back(); </script>";
	}
	else {

		echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=23'; </script>";
	}
}



	}

	class Genero { 
    
      var  $codigogenero;
      var $nombre;



	 function Genero ($_codigogenero, $_nombre) {

		$this -> codigogenero = $_codigogenero;
		$this -> nombre = $_nombre;
	}

	public static function insertar ($_codigogenero, $_nombre) 
	{

		include ("../conexion/conexion.php");

		$sql = mysqli_query($cnn, "select codigogenero from genero where codigogenero = '$_codigogenero' and estado = 'V' ");

		$rows = mysqli_num_rows($sql);
		if ($rows == 0) {

			$sql = mysqli_query($cnn, "insert into genero ( codigogenero, nombre, estado ) values ('$_codigogenero', '$_nombre', 'V')");

			echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=43' </script>";
		}
		else {

			echo  "<script type='text/javascript'> alert ('No existe el registro'); history.back(); </script>";
		}

		}

		public static function listar ($_opc, $_campo, $_valor) {

			include("../conexion/conexion.php");
			$matriz = array();

			if($_opc == 43) {

				$query = "select codigogenero, nombre from genero where estado = 'V' order by nombre";

			}
			else if ($_opc == 45) {

				$query = "select codigogenero, nombre from genero where estado = 'V' and codigogenero = '$_valor'";
			}
			else if ($_opc == 47) {

				$query = "select genero.codigogenero, genero.nombre from genero inner join generopelicula on genero.codigogenero = generopelicula.codigogenero inner join pelicula on generopelicula.idpelicula = pelicula.idpelicula where pelicula.idpelicula = '$_valor';";
			}

			$sql = mysqli_query($cnn, $query);
			$rows = mysqli_num_rows($sql);

			for($i = 0; $i < $rows; $i++) {   

				$dato = mysqli_fetch_array($sql);

				array_push($matriz, Genero :: mostrar($dato));
			}
			return $matriz;
		}

		public static function mostrar($dato) {

		$_codigogenero = $dato ["codigogenero"];
		$_nombre = $dato ["nombre"];
		$genero = new Genero ($_codigogenero, $_nombre);

		return $genero;
	}

	public static function eliminar($_codigogenero){

 include ("../conexion/conexion.php");

 $sql = mysqli_query($cnn, "update genero set estado = 'F' where codigogeneror = '$_codigogenero'");

 $rows = mysqli_affected_rows($cnn);

 if ($rows == 0 ) {

 	echo "<script type='text/javascript'> alert('No se eliminó el Registro'); history.back(); </script>";
 }
 else {

 	echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=43'; </script>";
 }
}

 public static function modificar ($_codigogenero, $_nombre) {

	include ("../conexion/conexion.php");
	$sql = mysqli_query($cnn, "update genero set nombre = '$_nombre' where codigogenero = '$_codigogenero' ");

	$rows = mysqli_affected_rows($cnn);

	if($rows == 0) {

		echo "<script type= 'text/javascript'> alert ('No se puede modificar el registro'); history.back(); </script>";
	}
	else {

		echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=43'; </script>";
	}
}

}

class Pelicula  {

	var $idpelicula;
	var $titulooriginal;
	var $titulolatino;
	var $resena;
	var $imagen;
	var $tamano;
	var $tipo;
	var $publicacion;

	function Pelicula ($_idpelicula, $_titulooriginal, $_titulolatino, $_resena, $_imagen, $_tamano, $_tipo, $_publicacion) {

		$this -> idpelicula = $_idpelicula;
		$this -> titulooriginal = $_titulooriginal;
		$this -> titulolatino = $_titulolatino;
		$this -> resena = $_resena;
		$this -> imagen = $_imagen;
		$this -> tamano = $_tamano;
		$this -> tipo = $_tipo;
		$this -> publicacion = $_publicacion;
 

	}

	public static function insertar ($_titulooriginal, $_titulolatino, $_resena, $_imagen, $_tamano, $_tipo, $_publicacion) {

		include ("../conexion/conexion.php");
		$sql = mysqli_query($cnn, "select titulooriginal from pelicula where titulooriginal = '$_titulooriginal' and estado = 'V' ");

		$rows = mysqli_num_rows($sql);

		if ($rows == 0) {

// establece para almacenar los archivos 
			$_ruta = "../pelicula/" . $_imagen;

			// copia la imagen a la ruta especifica 
			copy($_FILES["imagen"]["tmp_name"], $_ruta);

			$sql = mysqli_query($cnn, "insert into pelicula(titulooriginal, titulolatino, resena, imagen, tamano, tipo, publicacion, estado) values('$_titulooriginal', '$_titulolatino', '$_resena', '$_ruta', '$_tamano', '$_tipo', '$_publicacion', 'V')");

			
			echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=63'; </script>";
		}
		else {
		
			echo  "<script type='text/javascript'> alert('Ya existe la pélicula'); history.back(); </script>";
		}
	}

	public static function listar ($_opc, $_campo, $_valor) {

		include ("../conexion/conexion.php");
		$matriz = array();

		if($_opc == 63) {

			$query = "select idpelicula, titulooriginal, titulolatino, resena, imagen, tamano, tipo,  publicacion from pelicula  where estado = 'V' ";
		}
		else if ($_opc == 65) {

			$query = "select idpelicula, titulooriginal, titulolatino, resena, imagen, tamano, tipo,  publicacion from pelicula  where estado = 'V' and idpelicula = '$_valor'";


		}
		else if ($_opc == 69) {

		$query = "select pelicula.idpelicula, pelicula.titulooriginal, pelicula.titulolatino, pelicula.resena, pelicula.imagen, pelicula.tamano, pelicula.tipo, pelicula.publicacion from pelicula inner join actorpelicula on pelicula.idpelicula = actorpelicula.idpelicula inner join actor on actor.codigoactor = actorpelicula.codigoactor where actor.codigoactor = '$_valor';";
		}
		else if ($_opc == 70) {

			$query = "select pelicula.idpelicula, pelicula.titulooriginal, pelicula.titulolatino, pelicula.resena, pelicula.imagen, pelicula.tamano, pelicula.tipo, pelicula.publicacion from pelicula inner join directorpelicula on pelicula.idpelicula = directorpelicula.idpelicula inner join director on directorpelicula.codigodirector = director.codigodirector where director.codigodirector = '$_valor';";
		}
		else if ($_opc == 71) {

			$query = "select pelicula.idpelicula, pelicula.titulooriginal, pelicula.titulolatino, pelicula.resena, pelicula.imagen, pelicula.tamano, pelicula.tipo, pelicula.publicacion from pelicula inner join generopelicula on pelicula.idpelicula = generopelicula.idpelicula inner join genero on genero.codigogenero = generopelicula.codigogenero where genero.codigogenero = '$_valor';";
		}

		$sql = mysqli_query($cnn, $query);
		$rows = mysqli_num_rows($sql);

		for ($i = 0; $i < $rows; $i++) {

			$dato = mysqli_fetch_array($sql);
			array_push($matriz, Pelicula :: mostrar ($dato));

		}
		return $matriz;
	}

	public static function mostrar ($dato) {

		$_idpelicula = $dato["idpelicula"];
		$_titulooriginal = $dato["titulooriginal"];
		$_titulolatino = $dato["titulolatino"];
		$_resena = $dato["resena"];
		$_imagen = $dato["imagen"];
		$_tamano = $dato["tamano"];
		$_tipo = $dato["tipo"];
		$_publicacion = $dato["publicacion"];


		$pelicula = new Pelicula ($_idpelicula, $_titulooriginal, $_titulolatino, $_resena, $_imagen, $_tamano, $_tipo, $_publicacion);

		return $pelicula;
	}

	public static function eliminar ($_idpelicula) {

	include ("../conexion/conexion.php");
	$sql = mysqli_query($cnn, "update pelicula  set estado = 'F' where  idpelicula  = '$_idpelicula'");
	$rows = mysqli_affected_rows($cnn);

	if ($rows == 0) {

		echo "<script type='text/javascript'> alert ('No se eliminó el Registro');  history.back(); </script>";

	}
	else {

		echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=63'; </script>";
	}
}
  public static function modificar ($_idpelicula, $_titulooriginal, $_titulolatino, $_resena, $_imagen, $_tamano, $_tipo, $_publicacion) {

  	include ("../conexion/conexion.php");

  	if (empty($_imagen)) {

  		$query = "update pelicula set titulooriginal = '$_titulooriginal', titulolatino = '$_titulolatino', resena = '$_resena', publicacion = '$_publicacion', where idpelicula = '$_idpelicula'";
  	}
  	else {

  		$_ruta = "../pelicula/" . $_imagen;
			copy($_FILES["imagen"]["tmp_name"], $_ruta);

			$query = "update pelicula set titulooriginal = '$_titulooriginal', titulolatino = '$_titulolatino', resena = '$_resena', imagen = '$_ruta', tamano = '$_tamano', tipo = '$_tipo', publicacion = '$_publicacion' where idpelicula = '$_idpelicula'";
  	}

  	$sql = mysqli_query($cnn, $query);
  	$rows = mysqli_affected_rows($cnn);

  	if ($rows == 0) {

  		echo "<script type='text/javascript'> alert('No se modificó el registro'); history.back(); </script> ";
  	}
  	else {

  		echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=63';  </script> ";

  	}


  }
}


class Actorpelicula {

	 var $id;
	 var $nombre;
	 var $titulooriginal;
	 var $titulolatino;
	 


	 function Actorpelicula ($_id, $_nombre, $_titulooriginal, $_titulolatino) {


	 	$this -> id = $_id;
	 	$this -> nombre = $_nombre;
	 	$this -> titulooriginal = $_titulooriginal;
	 	$this -> titulolatino = $_titulolatino;
	 }

	 public static function insertar ($_codigoactor, $_idpelicula) 
	 {

	 		include ("../conexion/conexion.php");
	 		$sql = mysqli_query($cnn, "select codigoactor, idpelicula from Actorpelicula where codigoactor = '$_codigoactor' and idpelicula = '$_idpelicula'");

	 		$rows = mysqli_num_rows ($sql);

	  		if ($rows == 0) {

	  			$sql = mysqli_query($cnn, "insert into actorpelicula (codigoactor, idpelicula, estado) values ('$_codigoactor', '$_idpelicula', 'V')");
	  			echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=83'; </script>";
	  		}
	  		else {

	  			echo "<script type='text/javascript'> alert ('Ya existe este registro'); history.back(); </script>";
	  		}


	 }

	 public static function listar ($_opc, $_campo, $_valor) {

	 	include("../conexion/conexion.php");
	 	$matriz = array();

	 	if ($_opc == 83) {

	 		$query = "select actorpelicula.id, actor.nombre, pelicula.titulooriginal, pelicula.titulolatino from pelicula inner join actorpelicula on pelicula.idpelicula = actorpelicula.idpelicula inner join actor on actor.codigoactor = actorpelicula.codigoactor where actorpelicula.estado = 'V' order by actor.nombre";
	 	}

	 	$sql = mysqli_query($cnn, $query);
	 	$rows = mysqli_num_rows($sql);

	 	for ($i = 0; $i < $rows; $i++) {

	 		$dato = mysqli_fetch_array($sql);
	 		array_push($matriz, Actorpelicula :: mostrar($dato));

	 	}

	 	return $matriz;
	 }

	 public static function mostrar ($dato) {

	 	$_id = $dato["id"];
	 	$_nombre = $dato["nombre"];
	 	$_titulooriginal = $dato["titulooriginal"];
	 	$_titulolatino = $dato["titulolatino"];


	 	$actorpelicula = new Actorpelicula($_id, $_nombre, $_titulooriginal, $_titulolatino);

	 	return $actorpelicula;
	 }

	public static function eliminar ($_id) {

		include("../conexion/conexion.php");
		$sql = mysqli_query($cnn, "update actorpelicula set estado = 'F' where id = '$_id'");

		$rows = mysqli_affected_rows($cnn);

		if($rows == 0) {

			echo "<script type='text/javascript'> alert ('No se eliminó el registro'); history.back(); </script>";
		}

		else {

			echo  "<script type='text/javascript'> window.location.href='../control/facade.php?opc=83'; </script>";
		}
	}
}

class Directorpelicula {

	 var $id;
	 var $nombre;
	 var $titulooriginal;
	 var $titulolatino;
	 


	 function Directorpelicula ($_id, $_nombre, $_titulooriginal, $_titulolatino) {


	 	$this -> id = $_id;
	 	$this -> nombre = $_nombre;
	 	$this -> titulooriginal = $_titulooriginal;
	 	$this -> titulolatino = $_titulolatino;
	 }

	 public static function insertar ($_codigodirector, $_idpelicula) 
	 {

	 		include ("../conexion/conexion.php");
	 		$sql = mysqli_query($cnn, "select codigodirector, idpelicula from Directorpelicula where codigodirector = '$_codigodirector' and idpelicula = '$_idpelicula'");

	 		$rows = mysqli_num_rows ($sql);

	  		if ($rows == 0) {

	  			$sql = mysqli_query($cnn, "insert into directorpelicula (codigodirector, idpelicula, estado) values ('$_codigodirector', '$_idpelicula', 'V')");
	  			echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=103'; </script>";
	  		}
	  		else {

	  			echo "<script type='text/javascript'> alert ('Ya existe este registro'); history.back(); </script>";
	  		}


	 }

	 public static function listar ($_opc, $_campo, $_valor) {

	 	include("../conexion/conexion.php");
	 	$matriz = array();

	 	if ($_opc == 103) {

	 		$query = "select directorpelicula.id, director.nombre, pelicula.titulooriginal, pelicula.titulolatino from pelicula inner join directorpelicula on pelicula.idpelicula = directorpelicula.idpelicula inner join director on director.codigodirector = directorpelicula.codigodirector where directorpelicula.estado = 'V' order by director.nombre";
	 	}

	 	$sql = mysqli_query($cnn, $query);
	 	$rows = mysqli_num_rows($sql);

	 	for ($i = 0; $i < $rows; $i++) {

	 		$dato = mysqli_fetch_array($sql);
	 		array_push($matriz, Directorpelicula :: mostrar($dato));

	 	}

	 	return $matriz;
	 }

	 public static function mostrar ($dato) {

	 	$_id = $dato["id"];
	 	$_nombre = $dato["nombre"];
	 	$_titulooriginal = $dato["titulooriginal"];
	 	$_titulolatino = $dato["titulolatino"];


	 	$directorpelicula = new Directorpelicula($_id, $_nombre, $_titulooriginal, $_titulolatino);

	 	return $directorpelicula;
	 }

	public static function eliminar ($_id) {

		include("../conexion/conexion.php");
		$sql = mysqli_query($cnn, "update directorpelicula set estado = 'F' where id = '$_id'");

		$rows = mysqli_affected_rows($cnn);

		if($rows == 0) {

			echo "<script type='text/javascript'> alert ('No se eliminó el registro'); history.back(); </script>";
		}

		else {

			echo  "<script type='text/javascript'> window.location.href='../control/facade.php?opc=103'; </script>";
		}
	}
}

 class Generopelicula {

	 var $id;
	 var $nombre;
	 var $titulooriginal;
	 var $titulolatino;
	 


	 function Generopelicula ($_id, $_nombre, $_titulooriginal, $_titulolatino) {


	 	$this -> id = $_id;
	 	$this -> nombre = $_nombre;
	 	$this -> titulooriginal = $_titulooriginal;
	 	$this -> titulolatino = $_titulolatino;
	 }

	 public static function insertar ($_codigogenero, $_idpelicula) 
	 {

	 		include ("../conexion/conexion.php");
	 		$sql = mysqli_query($cnn, "select codigogenero, idpelicula from Generopelicula where codigogenero = '$_codigogenero' and idpelicula = '$_idpelicula'");

	 		$rows = mysqli_num_rows ($sql);

	  		if ($rows == 0) {

	  			$sql = mysqli_query($cnn, "insert into generopelicula (codigogenero, idpelicula, estado) values ('$_codigogenero', '$_idpelicula', 'V')");
	  			echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=123'; </script>";
	  		}
	  		else {

	  			echo "<script type='text/javascript'> alert ('Ya existe este registro'); history.back(); </script>";
	  		}


	 }

	 public static function listar ($_opc, $_campo, $_valor) {

	 	include("../conexion/conexion.php");
	 	$matriz = array();

	 	if ($_opc == 123) {

	 		$query = "select generopelicula.id, genero.nombre, pelicula.titulooriginal, pelicula.titulolatino from pelicula inner join generopelicula on pelicula.idpelicula = generopelicula.idpelicula inner join genero on genero.codigogenero = generopelicula.codigogenero where generopelicula.estado = 'V' order by genero.nombre";
	 	}

	 	$sql = mysqli_query($cnn, $query);
	 	$rows = mysqli_num_rows($sql);

	 	for ($i = 0; $i < $rows; $i++) {

	 		$dato = mysqli_fetch_array($sql);
	 		array_push($matriz, Generopelicula :: mostrar($dato));

	 	}

	 	return $matriz;
	 }

	 public static function mostrar ($dato) {

	 	$_id = $dato["id"];
	 	$_nombre = $dato["nombre"];
	 	$_titulooriginal = $dato["titulooriginal"];
	 	$_titulolatino = $dato["titulolatino"];


	 	$generopelicula = new Generopelicula($_id, $_nombre, $_titulooriginal, $_titulolatino);

	 	return $generopelicula;
	 }

	public static function eliminar ($_id) {

		include("../conexion/conexion.php");
		$sql = mysqli_query($cnn, "update generopelicula set estado = 'F' where id = '$_id'");

		$rows = mysqli_affected_rows($cnn);

		if($rows == 0) {

			echo "<script type='text/javascript'> alert ('No se eliminó el registro'); history.back(); </script>";
		}

		else {

			echo  "<script type='text/javascript'> window.location.href='../control/facade.php?opc=123'; </script>";
		}
	}
} 

class Usuario{
	
	var $usuario;
	var $clave;


	function Usuario ($_usuario, $_clave) {


		$this -> usuario = $_usuario;
		$this -> clave = $_clave;
	}

	public static function insertar ($_usuario, $_clave)
	{
		include ("../conexion/conexion.php");


		$sql = mysqli_query($cnn, "select usuario from usuario where usuario = '$_usuario' and estado = 'V' ");

		$rows = mysqli_num_rows($sql);
		if ($rows== 0) {

			$sql = mysqli_query($cnn, "insert into usuario( usuario, clave, estado) values ('$_usuario', sha1('$_clave'), 'V')");
            echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=143' </script>";

		}
		else {

			echo "<script type='text/javascript'> alert('No existe el registro'); history.back(); </script>";
		}
	}
	public static function listar ($_opc, $_campo, $_valor) {

		//matriz para recolectar los datos de la BD segun la consulta
 
		include ("../conexion/conexion.php");
		$matriz = array();

		if($_opc == 143) {
		$query = "select usuario, clave from usuario where estado = 'V' order by usuario";

	   }
	  else if ($_opc == 145) {

	   	 $query = "select usuario, clave from usuario where estado = 'V' and usuario = '$_valor' ";
	   }

	   $sql = mysqli_query ($cnn, $query);
	   $rows = mysqli_num_rows ($sql);

	   	for($i = 0; $i < $rows; $i++) {

	   		$dato = mysqli_fetch_array($sql);

	   	array_push ($matriz, Usuario :: mostrar($dato));
	   	}
	   return $matriz;

		}

	public static function mostrar($dato) {

		$_usuario = $dato ["usuario"];
		$_clave = $dato ["clave"];
		$usuario = new Usuario ($_usuario, $_clave);

		return $usuario;
	}

	public static function eliminar($_usuario){

 include ("../conexion/conexion.php");

 $sql = mysqli_query($cnn, "update usuario set estado = 'F' where usuario = '$_usuario'");

 $rows = mysqli_affected_rows($cnn);

 if ($rows == 0 ) {

 	echo "<script type='text/javascript'> alert('No se eliminó el Registro'); history.back(); </script>";
 }
 else {

 	 echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=143'; </script>";
  }
 }

  public static function acceso ($_usuario, $_clave) {

	 include ("../conexion/conexion.php");
	 $sql = mysqli_query($cnn, "select usuario, clave from usuario where usuario = '$_usuario' and clave = sha1('$_clave') and estado = 'V' ");

	 $rows = mysqli_num_rows($sql);
	 if ($rows == 0) {

	 	echo "<script type='text/javascript'> alert('Usuario y/o Clave son incorrectos'); history.back(); </script>";
	}
	  else {

		 $_SESSION["user"] = $_usuario;
	       }
   }
   		//MODIFICAR DE ADMINISTRADORES  / FALLOS EN EL OPC 159 SIN SOLUCIONAR
   			public static function modificar ($_usuario, $_clave) {

	include ("../conexion/conexion.php");
	$sql = mysqli_query($cnn, "update usuario set clave = sha1('$_clave') where usuario = '$_usuario'");

	$rows = mysqli_affected_rows($cnn);
        
	if($rows == 0) {

		echo "<script type= 'text/javascript'> alert ('No se puede modificar el registro'); history.back(); </script>";
	}
	else {

		echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=143'; </script>";
	}


 }

}



 	//DAO PARA REGISTRO E INGRESO 

  		class Usuarioing{
	
       	var $usuarioing;
	       var $claveing;
	        var $cedula;


	      function Usuarioing ($_usuarioing, $_claveing, $_cedula) {


	    	$this -> usuarioing = $_usuarioing;
		     $this -> claveing = $_claveing;
	      	$this -> cedula = $_cedula;
	     }

	   public static function insertar ($_usuarioing, $_claveing, $_cedula)
	  {
	   	include ("../conexion/conexion.php");


		$sql = mysqli_query($cnn, "select usuarioing from ingreso where usuarioing = '$_usuarioing' and estado = 'V' ");

		$rows = mysqli_num_rows($sql);
		if ($rows== 0) {

			$sql = mysqli_query($cnn, "insert into ingreso(usuarioing, claveing, cedula, estado) values ('$_usuarioing', sha1('$_claveing'), '$_cedula', 'V')"); //ARREGLAR OPC 143 PARA INGRESO PENDIENTE

            echo "<script type='text/javascript'> window.location.href='../vista/ingreso.php' </script>"; 

		}
		else {

			echo "<script type='text/javascript'> alert('No existe el registro'); history.back(); </script>";
		}
	}


	    public static function eliminar($_usuarioing){

 include ("../conexion/conexion.php");

 $sql = mysqli_query($cnn, "update ingreso set estado = 'F' where usuarioing = '$_usuarioing'");

 $rows = mysqli_affected_rows($cnn);

 if ($rows == 0 ) {

 	echo "<script type='text/javascript'> alert('No se eliminó el Registro'); history.back(); </script>";
 }
 else {
 																																			
 	 echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=143'; </script>";
  }
 }

  public static function acceso ($_usuarioing, $_claveing) {

	 include ("../conexion/conexion.php");
	 $sql = mysqli_query($cnn, "select usuarioing, claveing from ingreso where usuarioing = '$_usuarioing' and claveing = sha1('$_claveing') and estado = 'V' ");

	 $rows = mysqli_num_rows($sql);
	 if ($rows == 0) {

	 	echo "<script type='text/javascript'> alert('Usuario y/o Clave son incorrectos'); history.back(); </script>";
	}
	  else {

		 $_SESSION["user"] = $_usuarioing;
	       } 
   }


    public static function listar ($_opc, $_campo, $_valor) {

		//matriz para recolectar los datos de la BD segun la consulta
 
		include ("../conexion/conexion.php");
		$matriz = array();

		if($_opc == 155) {
		$query = "select usuarioing, claveing, cedula from ingreso where estado = 'V' order by usuarioing";

	   }
	  else if ($_opc == 156) { // VALIDAR OPC, EN CONFUSION, FALTA CREAR EL CAMPO MOSTRAR

	 $query = "select usuarioing, claveing, cedula from ingreso where estado = 'V' and usuarioing = '$_valor' ";
	   }

	   $sql = mysqli_query ($cnn, $query);
	   $rows = mysqli_num_rows ($sql);

	   	for($i = 0; $i < $rows; $i++) {

	   		$dato = mysqli_fetch_array($sql);

	   	array_push ($matriz, Usuarioing :: mostraring($dato));
	   	}
	   return $matriz;

		}
		//CREAR EL CAMPO MOSTRAR 

		public static function mostraring($dato) {

		
		$_usuarioing = $dato ["usuarioing"];
		$_claveing = $dato ["claveing"];
		$_cedula = $dato ["cedula"];
		$usuarioing = new Usuarioing ($_usuarioing, $_claveing, $_cedula);

		return $usuarioing;
	}       

	  public static function modificaring ($_usuarioing, $_claveing, $_cedula) {

	include ("../conexion/conexion.php");

	$sql = mysqli_query($cnn, "update ingreso set usuarioing = '$_usuarioing', claveing = sha1('$_claveing') where cedula = '$_cedula'");

	$rows = mysqli_affected_rows($cnn);
        
	if($rows == 0) {

		echo "<script type= 'text/javascript'> alert ('No se puede modificar el registro'); history.back(); </script>";
	}
	else {

		echo "<script type='text/javascript'> window.location.href='../control/facade.php?opc=143'; </script>";
	}
}
}





?> 