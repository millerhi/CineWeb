<?php session_start();?>


<?php
include $_SERVER['DOCUMENT_ROOT'] . '/cine/control/DAO.php';

switch ($_REQUEST["opc"]) {


	case 2:

	$codigoactor = $_POST["codigoactor"];
	$nombre = $_POST["nombre"];

	// invocacion del metodo de insertar  y sus parametros


	Actor :: insertar($codigoactor, $nombre);
	exit();
	break;


	case 3:

	$opc = 3;
	$campo = 0;
	$valor =0;
	$aActor = Actor :: listar ($opc, $campo, $valor);
	include ("../vista/actor.php");
	exit();
	break;

	case 4:

	$codigoactor = $_REQUEST["codigoactor"];
	Actor :: eliminar ($codigoactor);
	exit();
	break;

	case 5:

   $opc = 5;
   $campo = 0;
   $valor = $_REQUEST["codigoactor"];
   $aActor = Actor :: listar($opc, $campo, $valor);
   include ("../vista/actormodificar.php");
   exit();
   break;


   case 6:

   $codigoactor = $_POST["codigoactor"];
   $nombre = $_POST["nombre"];
   Actor :: modificar ($codigoactor, $nombre);
   exit();
   break;



   case 22: 

	$codigodirector = $_POST["codigodirector"];
	$nombre = $_POST["nombre"];

    Director :: insertar($codigodirector, $nombre);
	exit();
	break; 

	case 23: 
 
	$opc = 23;
	$campo = 0;
	$valor =0;
	$aDirector = Director :: listar ($opc, $campo, $valor);
	include ("../vista/director.php");
	exit();
	break;

	case 24:

	$codigodirector = $_REQUEST["codigodirector"];
	Director :: eliminar ($codigodirector);
	exit();
	break;

	case 25: 

	 $opc = 25;
   $campo = 0;
   $valor = $_REQUEST["codigodirector"];
   $aDirector = Director :: listar($opc, $campo, $valor);
   include ("../vista/directormodificar.php");
   exit();
   break;

   case 26: 

    $codigodirector = $_POST["codigodirector"];
   $nombre = $_POST["nombre"];
   Director :: modificar ($codigodirector, $nombre);
   exit();
   break;

//https://www.youtube.com/watch?v=t7dWFUggkno

case 42:

$codigogenero = $_POST["codigogenero"];
$nombre = $_POST["nombre"];

Genero :: insertar($codigogenero, $nombre);
exit();
break;

case 43: 

$opc = 43;
$campo = 0;
$valor =0;
$aGenero = Genero :: listar ($opc, $campo, $valor);
include ("../vista/genero.php");
exit();
break;

case 44:

$codigogenero = $_REQUEST["codigogenero"];
Genero :: eliminar ($codigogenero);
exit();
break;

case 45: 
 
   $opc = 45;
   $campo = 0;
   $valor = $_REQUEST["codigogenero"];
   $aGenero = Genero :: listar($opc, $campo, $valor);
   include ("../vista/generomodificar.php");
   exit();
   break;

   case 46: 

    $codigogenero = $_POST["codigogenero"];
   $nombre = $_POST["nombre"];
   Genero :: modificar ($codigogenero, $nombre);
   exit();
   break;

   case 62: 
 
   $titulooriginal  = $_POST["titulooriginal"];
   $titulolatino = $_POST["titulolatino"];
   $resena = $_POST["resena"];
   $imagen = $_FILES["imagen"]["name"];
   $tamano = $_FILES["imagen"]["size"];
   $tipo = $_FILES["imagen"]["type"];
   $publicacion = $_POST["publicacion"];
  
   Pelicula :: insertar ($titulooriginal, $titulolatino, $resena, $imagen, $tamano, $tipo, $publicacion);
    exit();
   break;

   case 63: 

   $opc = 63;
   $campo = 0;
   $valor = 0;

   $aPelicula = Pelicula :: listar ($opc, $campo, $valor);
   include ("../vista/pelicula.php");
   exit();
   break;


   case 64:

   $idpelicula = $_REQUEST["idpelicula"];
   Pelicula :: eliminar ($idpelicula);
   exit();
   break;

   case 65:

   $opc = 65;
   $campo = 0;
   $valor = $_REQUEST["idpelicula"];

   $aPelicula = Pelicula :: listar ($opc, $campo, $valor);
   include ("../vista/peliculamodificar.php");
   exit();
   break;


   case 66:

    $idpelicula = $_POST["idpelicula"];
    $titulooriginal = $_POST["titulooriginal"];
    $titulolatino = $_POST["titulolatino"];
    $resena = $_POST["resena"];
    $imagen = $_FILES["imagen"] ["name"];
    $tamano = $_FILES["imagen"] ["size"];
    $tipo = $_FILES["imagen"] ["type"];
    $publicacion = $_POST["publicacion"];

    Pelicula :: modificar ($idpelicula, $titulooriginal, $titulolatino, $resena, $imagen, $tamano, $tipo, $publicacion);
    exit();
    break;

    case 67:

    $opc = 63;
     $campo = 0;
     $valor = 0;

     $aPelicula = Pelicula :: listar ($opc, $campo, $valor);
     include ("../vista/index.php");
    exit();
    break;

    case 68:

    $opc = 7;
    $campo = 0;
    $valor = $_REQUEST["idpelicula"];
    $aActor = Actor :: listar ($opc, $campo, $valor);

    $opc= 27;
    $campo = 0;
    $valor = $_REQUEST["idpelicula"];
    $aDirector = Director :: listar ($opc, $campo, $valor);

    $opc = 47;
    $campo = 0;
    $valor = $_REQUEST["idpelicula"];
    $aGenero = Genero :: listar ($opc, $campo, $valor);


    $opc = 65;
    $campo = 0;
    $valor = $_REQUEST["idpelicula"];
    $aPelicula = Pelicula :: listar ($opc, $campo, $valor);
    include ("../vista/detallepelicula.php");
     exit();
     break;

     case 69:

      $opc = 69;
      $campo = 0;
      $valor = $_REQUEST["codigoactor"];
      $aPelicula = Pelicula :: listar ($opc, $campo, $valor);
      include ("../vista/index.php");
      exit();
      break;


      case 70:

      $opc = 70;
      $campo = 0;
      $valor = $_REQUEST["codigodirector"];
      $aPelicula = Pelicula :: listar ($opc, $campo, $valor);
      include ("../vista/index.php");
      exit();
      break;

      case 71:

       $opc = 71;
       $campo = 0;
       $valor = $_REQUEST["codigogenero"];
       $aPelicula = Pelicula :: listar ($opc, $campo, $valor);
       include ("../vista/index.php");
       exit();
       break;
 


     case 82 :

     $codigoactor = $_POST["codigoactor"];
     $idpelicula = $_POST["idpelicula"];
     Actorpelicula :: insertar ($codigoactor, $idpelicula);

      exit();
      break;


    case 83:

    //Llamado de el listar de actor

    $opc = 3;
    $campo = 0;
    $valor = 0;
    $aActor = Actor :: listar ($opc, $campo, $valor);


    //Llamado de listar de pelicula

    $opc = 63;
    $campo = 0;
    $valor = 0;
    $aPelicula = Pelicula :: listar ($opc, $campo, $valor);


    $opc = 83;
    $campo = 0;
    $valor = 0;
    $aActorpelicula = Actorpelicula :: listar ($opc, $campo, $valor);

    include ("../vista/actorpelicula.php");
    exit();
    break; 

    case 84:


     $id = $_REQUEST["id"];
     Actorpelicula :: eliminar($id);
     exit();
     break;


/// LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL


      case 102 :

     $codigodirector = $_POST["codigodirector"];
     $idpelicula = $_POST["idpelicula"];
     Directorpelicula :: insertar ($codigodirector, $idpelicula);

      exit();
      break;

     case 103:

     $opc = 23;
     $campo = 0;
     $valor = 0;
     $aDirector = Director :: listar ($opc, $campo, $valor);


    $opc = 63;
    $campo = 0;
    $valor = 0;
    $aPelicula = Pelicula :: listar ($opc, $campo, $valor);


    $opc = 103;
    $campo = 0;
    $valor = 0;
    $aDirectorpelicula = Directorpelicula :: listar ($opc, $campo, $valor);

    include ("../vista/directorpelicula.php");
    exit();
    break;

     case 104:


     $id = $_REQUEST["id"];
     Directorpelicula :: eliminar($id);
     exit();
     break;


     case 122:

      $codigogenero = $_POST["codigogenero"];
     $idpelicula = $_POST["idpelicula"];
     Generopelicula :: insertar ($codigogenero, $idpelicula);

      exit();
      break;

      case 123:

      $opc = 43;
     $campo = 0;
     $valor = 0;
     $aGenero = Genero :: listar ($opc, $campo, $valor);


    $opc = 63;
    $campo = 0;
    $valor = 0;
    $aPelicula = Pelicula :: listar ($opc, $campo, $valor);


    $opc = 123;
    $campo = 0;
    $valor = 0;
    $aGeneropelicula = Generopelicula :: listar ($opc, $campo, $valor);

    include ("../vista/generopelicula.php");
    exit();
    break;




    case 124: 

     $id = $_REQUEST["id"];
     Generopelicula :: eliminar($id);
     exit();
     break;

     case 142: 

     
  $usuario = $_POST["usuario"];
  $clave = $_POST["clave"];

  Usuario :: insertar($usuario, $clave);
  exit();
  break;

  case 143: 

  $opc = 143;
  $campo = 0;
  $valor = 0;
  $aUsuario = Usuario :: listar ($opc, $campo, $valor); 

  case 155:
  $opc = 155;
  $campo = 0;
  $valor = 0;
  $aUsuarioing = Usuarioing :: listar ($opc, $campo, $valor);  
  

  include ("../vista/usuario.php");
  exit();
  break;

   case 144:

   $usuario = $_REQUEST["usuario"];
  Usuario :: eliminar ($usuario);
  exit();
  break;

    case 147:

    $usuario = $_POST["usuario"];
    $clave = $_POST["clave"];
    Usuario :: acceso ($usuario, $clave);
    include ("../vista/menu.php");
    exit();
    break;


    //CREAMOS ESTE CASE 150 PARA EL LLAMADO DEL REGISTO
    case 150: 

  $usuarioing = $_POST["usuarioing"];
  $claveing = $_POST["claveing"];
  $cedula = $_POST["cedula"];
  $aUsuario = Usuarioing :: listar ($opc, $campo, $valor);
  include ("../vista/index.php");
  exit();
  break;


//Se hace la creacion de un nuevo caso para la tabla registro en el BS
     case 152: 

  $usuarioing = $_POST["usuarioing"];
  $claveing = $_POST["claveing"];
  $cedula = $_POST["cedula"];  
  Usuarioing :: insertar($usuarioing, $claveing, $cedula);
  exit();
  break;


  //SE REALIZA LA CREACION DEL CASE 153 PARA EL ARCHIVO INGRESO.PHP, UNA VEZ SE INGRESE Y ESTE SEA VALIDADO CON USUARIO Y CONTRASEÑA LO DIRIJA AL ARCHIVO INDEX.PHP QUE EN SU CASO ES EL CASE 63
    case 153:

    $opc = 63;
  $campo = 0;
  $valor = 0;
  $aPelicula = Pelicula :: listar ($opc, $campo, $valor);
  
    $usuarioing = $_POST["usuarioing"];
    $claveing = $_POST["claveing"];
    Usuarioing :: acceso ($usuarioing, $claveing);
    include ("../vista/index.php");
    exit();
    break;

    case 154:
    $opc = 154;
     $usuarioing = $_REQUEST["usuarioing"];
       Usuarioing :: eliminar ($usuarioing);
         exit();
            break;

            case 158:

            $opc = 63;
              $campo = 0;
                $valor = 0;
                   $aPelicula = Pelicula :: listar ($opc, $campo, $valor);
                   include ("../vista/index.php");
                     exit();
                      break;


                       case 159: 
 
                          $usuario = $_POST["usuario"];
                         $clave = $_POST["clave"];
                         Usuario :: modificar ($usuario, $clave);
                         exit();
                         break;

                               case 160: //administradores

                                       $opc = 160;
                                      $campo = 0;
                                      $valor = $_REQUEST["usuario"];
                                      $aUsuario = Usuario :: listar ($opc, $campo, $valor);
                                      include ("../vista/usuariomodificar.php");
                                       exit();
                                       break;   




           case 180: //MODIFICAR USUARIOS
                              
         $usuarioing = $_POST["usuarioing"];
           $claveing = $_POST["claveing"];
           $cedula = $_POST["cedula"];
               Usuarioing :: modificaring ($usuarioing, $claveing, $cedula);
                     exit();
                        break;



                    case 179: // LISTAR USUARIOS 

                                   $opc = 179;
                                $campo = 0;
                              $valor = $_REQUEST["usuarioing"];;
                             $aUsuarioing = Usuarioing :: listar ($opc, $campo, $valor);
                             include("../vista/usuarioingmodificar.php");
                             exit();
                             break;

                           













                                            
}

?>

