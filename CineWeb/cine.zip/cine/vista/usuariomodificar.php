<?php @session_start();?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
		<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>
<body>
	<?php if(isset($_SESSION["user"])) { ?>


	<br> <br> 

	<table border="0" width="1200" align="center">

		<tr>

			<th align="center" class="sombra2">  <font size="7" class="eltitu" > ¡Películas Online! </font>   </th>


		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>
		


	</table>

	<form method="post" action="../control/facade.php?opc=159" onsubmit="return validarusuario()">
	<br> <br> 

	
<?php 


	foreach ($aUsuario as $lUsuario) { ?>
	

	<table border="0" width="600" align="center" class="tabla usuario">



		<tr>

			<th colspan="2"><font size="5" class="titulo usuario2">&nbsp;Modificación de Administradores &nbsp; </font> </th>

		</tr>



		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;<a href="../control/facade.php?opc=143"> <img src="../img/retornar.png" width="30"></a></td>

		</tr>


		<tr>



			<td class="campo">Usuario</td>
			<td><input type="text" name="usuario" id="usuario" size="23" maxlength="10" required="true" placeholder="Digite su nuevo Usuario" class="texto" value="<?php echo $lUsuario -> usuario;?>" > </td>

		</tr>

		<tr> 

			<td class="campo" >Clave</td>
			<td><input type="text" name="clave" id="clave" size="40" maxlength="40" required="true" placeholder="Digite su nueva Clave" class="texto" value="<?php echo $lUsuario -> clave;?>"> </td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>





		<tr>

			<th colspan="2"><input type="submit" value="Almacenar" class="boton" >&nbsp; <input type="reset" value="Restablecer" class="boton" > </th>
		</tr>
			

	 

	</table>

<?php } ?>
	
	<?php 
}

else {
  echo "<script type='text/javascript'> alert('Ingreso Incorrecto'); pagina = '../control/facade.php?opc=143'; tiempo= 10; ubicacion = '_self'; setTimeout('open(pagina, ubicacion)', tiempo); </script>";
}
?>
</form>
</body>
</html>