<?php @session_start();?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>
<body >
<?php if(isset($_SESSION["user"])) {?>
	<br> <br> 

	<table border="0" width="1200" align="center">

		<tr>

			<th align="center" class="sombra2">  <font size="7" class="eltitu" > ¡Películas Online! </font>   </th>


		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>
		


	</table>

	<form method="post" action="../control/facade.php?opc=42" onsubmit="return validagenero()">
	<br> <br> 

	<table border="0" width="600" align="center" class="tabla usuario">

		<tr>

			<th colspan="2" class="titulo usuario2">&nbsp;ADMINISTRACIÓN DE GÉNERO&nbsp; </font> </th>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;<a href="../vista/menu.php"> <img src="../img/retornar.png" width="30"></td>

		</tr>

		

		<tr>

			<td class="campo" align="center">Código</td>
			<td><input type="text" name="codigogenero" id="codigogenero" size="15" maxlength="5" required="true" placeholder="Digite Código" class="texto"> </td>

		</tr>

		<tr> 

			<td class="campo" align="center">Nombre</td>
			<td><input type="text" name="nombre" id="nombre" size="40" maxlength="40" required="true" placeholder="Digite Nombre" class="texto"> </td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>

			<th colspan="2"><input type="submit" value="Almacenar" class="boton" >&nbsp; <input type="reset" value="Restablecer" class="boton" > </th>
		</tr>
		

	</table>

</form>
<br>

<table width="600" border="0" align="center" class="tabla usuario">

	<tr>

		<th colspan="4" class="titulo usuario2">LISTA DE GÉNERO </th>

	</tr>

	<tr> 

		<td colspan="4">&nbsp;</td>
	</tr>

	<tr>

		<td class="campo" width="100" align="center">Código</td>
		<td class="campo" width="300" align="center">Nombre</td>
		<td></td>
		<td></td>

	</tr>

	<tr> 

		<td colspan="4">&nbsp;</td>
	</tr>

	<?php 

	 foreach ($aGenero as $lGenero) { ?>

	<tr> 

		<td width="100" class="campo" align="center"> &nbsp; <?php echo $lGenero -> codigogenero;?> </td>
		<td width="400" class="campo" align="center"> <?php echo $lGenero -> nombre; ?> </td>
		<td width="50"><a href="../control/facade.php?opc=44&codigogenero=<?php echo $lGenero -> codigogenero;?>"onClick="return confirm(' ¿Seguro de Eliminar este género?')" title="Eliminar"> <img src="../img/delete.png" width="32"> </a></td>

			<td width="50"> <a href="../control/facade.php?opc=45&codigogenero=<?php echo $lGenero-> codigogenero;?>"> <img src="../img/edit.png" width="32"> </a> </td>
	</tr>
	<?php  } ?>

	


</table>
<?php 
}
else {
  echo "<script type='text/javascript'> alert('Ingreso Incorrecto'); pagina = '../vista/acceso.php'; tiempo= 10; ubicacion = '_self'; setTimeout('open(pagina, ubicacion)', tiempo); </script>";
}
?>

</body>
</html>
