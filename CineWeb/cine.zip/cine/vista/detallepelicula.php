<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>
<body >

	<br> <br> 

	<table border="0" width="1200" align="center">

		<tr>

			<th align="center" class="sombra2">  <font size="7" class="eltitu" > ¡Películas Online! </font>   </th>


		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>
		
	</table>

	<table width="400" border="0" align="center" class="tabla usuario">
		
		<tr> 

			<th class="titulo usuario2 ">PELÍCULAS EN CARTELERA </th>
		</tr>

		<tr>

			<td><a href="../control/facade.php?opc=67"><img src="../img/retornar.png" width="30"> </a> </td>

		</tr>
		<tr>

			<td colspan="3">&nbsp; </td>
		</tr>
		<?php foreach ($aPelicula as $lPelicula) { ?>

		<tr>

			<td align="center"><img src="<?php echo $lPelicula -> imagen;?>" width="250"> </td> 
		</tr>

		<tr>
			
			 <td>&nbsp;</td>
			</tr>

			<tr>
				 
				 <td class="titulo usuario2" align="center">&nbsp;Título Película</td>
				</tr>

				<tr>
					
					<td class="campo2 "><?php echo $lPelicula -> titulooriginal;?><br> 
						<?php echo $lPelicula -> titulolatino;?></td>
				</tr>
			
		 <tr>
			
			 <td>&nbsp;</td>
			</tr>

			<tr>
				 
				 <td class="titulo usuario2" align="center">&nbsp;Reseña</td>
				</tr>

				<tr>
					
					<td class="campo2 "><?php echo $lPelicula -> resena;?></td>
				</tr>
			
		 <tr>
			
			 <td>&nbsp;</td>
			</tr>

			<tr>
				 
				 <td class="titulo usuario2" align="center">&nbsp;Año de publicación</td>
				</tr>

				<tr>
					
					<td class=" campo2 " align="center"><?php echo $lPelicula -> publicacion;?></td>
				</tr>
				<?php } ?>

				<tr> 
					<td>&nbsp;</td>
				</tr>
				<tr> 

					<td align="center" class="titulo usuario2">Actores</td>
				</tr>

				<tr> 

					<td class="campo2"> 
						<?php  foreach ($aActor as $lActor) { ?>

							<a href="../control/facade.php?opc=69&codigoactor=<?php echo $lActor -> codigoactor;?>"><?php echo $lActor -> nombre;?> </a>
						<?php } ?>
					</td>
				</tr>



						<tr> 
					<td>&nbsp;</td>
				</tr>
				<tr> 

					<td align="center" class="titulo usuario2">Directores</td>
				</tr>

				<tr> 

					<td class="campo2"> 
						<?php  foreach ($aDirector as $lDirector) { ?>

				<a href="../control/facade.php?opc=70&codigodirector=<?php echo $lDirector -> codigodirector;?>"><?php echo $lDirector -> nombre;?> </a>
						<?php } ?>
					</td>
				</tr>


						<tr> 
					<td>&nbsp;</td>
				</tr>
				<tr> 

					<td align="center" class="titulo usuario2">Géneros</td>
				</tr>

				<tr> 

					<td class="campo2"> 
						<?php  foreach ($aGenero as $lGenero) { ?>

			<a href="../control/facade.php?opc=71&codigogenero=<?php echo $lGenero-> codigogenero;?>"><?php echo $lGenero -> nombre;?> </a>
						<?php } ?>
					</td>
				</tr>	
			</table>
			
		</body>
		</html>
			
	
