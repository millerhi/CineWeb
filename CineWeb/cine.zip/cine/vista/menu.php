<?php @session_start();?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=urf-8" />
<title>Ménu</title>

</head>

<body bgcolor="#000000">
    


	<?php if(isset($_SESSION["user"])) {?>

<br />

<br />

<table width="490" border="0" align="center">
<tr>
  <td width="484">&nbsp;
    <?php include ("submenu.php");	?>
  </td>
</tr>
</table>
<?php 
}
else {
  echo "<script type='text/javascript'> alert('Ingreso Incorrecto'); pagina = '../vista/acceso.php'; tiempo= 10; ubicacion = '_self'; setTimeout('open(pagina, ubicacion)', tiempo); </script>";
}

?>
</body>
</html>