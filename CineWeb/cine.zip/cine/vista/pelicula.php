<?php @session_start();?>
<!DOCTYPE html>
<html>
<head>
	
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
	<meta charset="utf-8">
</head>
<body >
<?php if(isset($_SESSION["user"])) {?>
	<br> <br> 

	<table border="0" width="1200" align="center">

		<tr>

			<th align="center" class="sombra2">  <font size="7" class="eltitu" > ¡Películas Online! </font>   </th>


		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>
		


	</table>

	<form action="../control/facade.php?opc=62" method="post" onsubmit="return validarpelicula()" enctype="multipart/form-data">

		<table border="0" align="center" width="600" class="tabla usuario" >


			<tr> 

				<td align="center" colspan="2" class="titulo usuario2"> CONTROL DE PELÍCULAS </td>
			</tr>

			<tr>

				<td colspan="2">&nbsp;<a href="../vista/menu.php"> <img src="../img/retornar.png" width="35">  </td>
			</tr>

			<tr>

				<td colspan="2">&nbsp; </td>
			</tr>

			<tr>

				<td width="150" class="campo" align="center">Título Original </td>
				<td> <input type="text" name="titulooriginal" id="titulooriginal" size="45" maxlength="60" required="true" placeholder="Titulo Original" class="texto" > </td>

			</tr>
			
			<tr>

				<td width="150" class="campo" align="center">Título Latino </td>
				<td> <input type="text" name="titulolatino" id="titulolatino" size="45" maxlength="60" required="true" placeholder="Titulo Latino" class="texto" > </td>

			</tr>
			
			<tr> 
				<td valign="top" class="campo" align="center">Reseña</td>
				<td><textarea name="resena" id="resena" cols="45" rows="5" class="texto" required="true" placeholder="Reseña de la pelicula"></textarea> </td>

			</tr>

			<tr>

				<td width="150" class="campo" align="center">Imagen </td>
				<td> <input type="file" name="imagen" id="imagen" required="true" placeholder="Imagen" class="texto"> </td>

			</tr>


			<tr>

				<td width="150" class="campo" align="center">Año publicación </td>
				<td> <input type="text" name="publicacion" id="publicacion" size="10" maxlength="4" required="true" placeholder="Publicacion" class="texto" > </td>

			</tr>

			<tr>
				<td colspan="2">&nbsp; </td>
			</tr>

			<tr>

				<td colspan="2" align="center"> <input type="submit" value="Almacenar" class="boton">&nbsp; <input type="reset" value="Restablecer" class="boton"> </td>

			</tr>




			 



		</table>

	</form>
	<br>

	<table width="1000" border="0" align="center" class="tabla usuario">

      <tr> 

      	<th colspan="7" class="titulo usuario2" > LISTADO GENERAL DE PELÍCULAS </th> 
     
      </tr> 

     <tr> 

	<td width="150" class="campo border">Película</td>
	<td width="150" class="campo  border">Título</td>
	<td width="400" class="campo border">Reseña</td>
	<td width="70" class="campo border">Año de publicación</td>
	<td width="50">&nbsp;</td>
	<td width="50">&nbsp;</td>
</tr>

<tr> 

	<td colspan="6">&nbsp; </td>

</tr>
<?php foreach ($aPelicula as $lPelicula) { ?>
<tr> 

	<td width="150" class="campo"><img src="<?php echo $lPelicula -> imagen;?>" width="150"> </td>
	<td width="150" class="campo"> <?php echo $lPelicula -> titulooriginal;?>&nbsp;/&nbsp;<?php echo $lPelicula -> titulolatino;?>  </td>
	<td width="400" class="campo" > <?php echo $lPelicula -> resena;?></td>
	<td width="50" class="campo" align="center"> <?php echo $lPelicula -> publicacion;?> </td>
	<td width="50">&nbsp;<a href="../control/facade.php?opc=64&idpelicula=<?php echo $lPelicula -> idpelicula;?>"><img src="../img/delete.png" width="30">
	 </a> </td>

	<td width="50">&nbsp;<a href="../control/facade.php?opc=65&idpelicula=<?php echo $lPelicula -> idpelicula;?>"><img src="../img/edit.png" width="30"> 
	</a> </td>
</tr>

<?php } ?>

	 </table>
	 <?php 
}
else {
  echo "<script type='text/javascript'> alert('Ingreso Incorrecto'); pagina = '../vista/acceso.php'; tiempo= 10; ubicacion = '_self'; setTimeout('open(pagina, ubicacion)', tiempo); </script>";
}

?>

</body>
</html>