<?php @session_start();?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>
<body >
<?php if(isset($_SESSION["user"])) {?>
	<br> <br> 

	<table border="0" width="1200" align="center">

		<tr>

			<th align="center" class="sombra2">  <font size="7" class="eltitu" > ¡Películas Online! </font>   </th>


		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>
		


	</table>

	<form action="../control/facade.php?opc=66" method="post" onsubmit="return validarpelicula()" enctype="multipart/form-data">

		<?php foreach ($aPelicula as $lPelicula) { ?>

		<table border="0" align="center" width="600" class="tabla usuario">


			<tr> 

				<td align="center" colspan="2" class="titulo usuario2"> Control de películas </td>
			</tr>

			<tr>

				<td colspan="2">&nbsp;<a href="../control/facade.php?opc=63"> <img src="../img/retornar.png" width="30">  </td>
			</tr>

			<tr>

				<td colspan="2">&nbsp; </td>
			</tr>

			<tr>

				<td width="150" class="campo">Título Original </td>
				<td> <input type="text" name="titulooriginal" id="titulooriginal" size="45" maxlength="60" required="true" placeholder="Titulo Original" class="texto" value="<?php echo $lPelicula -> titulooriginal;?>"> </td>

			</tr>

			<tr> 

				<td class="campo"> ID </td>
				<td> <input type="text" name="idpelicula" id="pelicula" size="10" readonly value="<?php echo $lPelicula -> idpelicula;?>"> </td>

				</td>
			
			<tr>

				<td width="150" class="campo">Título Latino </td>
				<td> <input type="text" name="titulolatino" id="titulolatino" size="45" maxlength="60" required="true" placeholder="Titulo Latino" class="texto" value="<?php echo $lPelicula -> titulolatino;?>" > </td>

			</tr>
			
			<tr> 
				<td valign="top" class="campo">Reseña</td>
				<td><textarea name="resena" id="resena" cols="45" rows="5" class="texto" required="true" placeholder="Reseña de la pelicula"><?php echo $lPelicula -> resena;?>
				 </textarea> </td>

			</tr>

			<tr>

				<td class="campo"> Imagen Actual </td>
				<td> <img src="<?php echo $lPelicula -> imagen;?>" width="100"><input type="hidden" name="imagenactual" id="imagenactual" value="<?php echo $lPelicula -> imagen;?>"> </td>


			</tr>

			<tr>

				<td width="150" class="campo">Imagen </td>
				<td> <input type="file" name="imagen" id="imagen" required="true" placeholder="Imagen" class="texto"> </td>

			</tr>


			<tr>

				<td width="150" class="campo" >Año publicación </td>
				<td> <input type="text" name="publicacion" id="publicacion" size="10" maxlength="4" required="true" placeholder="Publicacion" class="texto" value="<?php echo $lPelicula -> publicacion;?>"> </td>

			</tr>

			<tr>
				<td colspan="2">&nbsp; </td>
			</tr>

			<tr>

				<td colspan="2"> <input type="submit" value="Almacenar" class="boton">&nbsp; <input type="reset" value="Restablecer" class="boton">
 
		</table>

	<?php } ?>

	<?php 
}
else {
  echo "<script type='text/javascript'> alert('Ingreso Incorrecto'); pagina = '../vista/acceso.php'; tiempo= 10; ubicacion = '_self'; setTimeout('open(pagina, ubicacion)', tiempo); </script>";
}

?>

	</form>
	<br>

	
</body>
</html>