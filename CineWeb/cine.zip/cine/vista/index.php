<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>

<body>

 	<header>

 		<section id="menu">
 			
 					<ul>
 						
 						<a href="../vista/ingreso.php"> Cerrar Sesión </a>
 						<a href="../vista/nosotros.php"> Nosotros</a>		
 						<a href="#redes"> Contáctanos </a>
		
 						

 					</ul>

 		</section>
 	</header>


 	<br> <br> <br> <br> <br> <br> <br>
	<table border="0" width="1000" align="center">


		<tr>

			<th align="center" class="sombra2">  <font size="7" class="eltitu" > ¡Películas Online! </font>   </th>


		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>
		
	</table>

	<table width="1000" border="0" align="center" class="tabla"> <p align="center">
		
		<tr> 

			<th colspan="3" class="titulo campo2"><font size="5">Películas en Cartelera  </font></th>
		</tr>
		<tr>

			<td colspan="3">&nbsp; </td>
		</tr>
		<tr>

			<td colspan="3" align="right">&nbsp;<a href="../control/facade.php?opc=67"><img src="../img/refresh_arrow_1546.png" width="45"> </a> </td>
		</tr>
		<tr>

			<td colspan="3">&nbsp; </td>
		</tr>

		<tr>

			<?php 

			$i = 0;
			foreach ($aPelicula as $lPelicula) {

			if ($i <3 ) {
			?>

				<td align="center"><a href="../control/facade.php?opc=68&idpelicula=<?php echo $lPelicula -> idpelicula;?>"><img src="<?php echo $lPelicula -> imagen;?>" width="250" class=""></a>  </td>
				<?php }

					else {

				echo "</tr>";
				echo "<tr>";
					$i = 0;

					?>

					<td align="center" ><a href="../control/facade.php?opc=68&idpelicula=<?php echo $lPelicula -> idpelicula;?>"><img src="<?php echo $lPelicula -> imagen;?>" width="250" class=""></a> </td>

					<?php }

					 $i++;
				
		 	} ?>
			 </tr>

	</table>
<br> <br> <br> <br>



 		<section id="redes">

	
 					<ul>
 						
 						<p> ¿Quiénes Somos? <br> Somos una empresa destinada a brindarle al cliente la mayor comodidad y facilidad para encontrar su película favorita.  </p> <br>
 						

 						<a href="https://es-la.facebook.com/"> <img src="../img/facebook.ico" width="30"> </a>
 						 						
 						<a href="https://www.instagram.com/"> <img src="../img/instagram.ico" width="30"> </a>

 						<a href="https://twitter.com/?lang=es"> <img src="../img/twiter.ico" width="30"> </a>
 						<br>
 						 <h1> CineWeb@gmail.com <b> | </b> AtenciónAlClienteCineWeb@gmail.com</h1>
 						<h1> Esteban Muñoz <b> | </b>  Samuel Molina <b> | </b>  Miller Hincapié  <b> | </b> Brayan Montes </h1>
 	
 					</ul>

 		</section>
 
		
					
</body>
</html>