<?php @session_start();?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>
<body >
<?php if(isset($_SESSION["user"])) {?>
	<br> <br> 

	<table border="0" width="1100" align="center">

		<tr>

			<th align="center" class="sombra2">  <font size="7" class="eltitu" > ¡Películas Online! </font>   </th>

		</tr>
	</table>
	
	<form method="post" action="../control/facade.php?opc=142" onsubmit="return validarusuario()"> </form>
	<br> <br> 

	<table border="0" width="540" align="center" class="tabla usuario">

		<tr>

			  <th colspan="2" class="titulo usuario2">&nbsp;ADMINISTRACIÓN DE USUARIOS CINEWEB&nbsp; </font> </th>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;<a href="../vista/menu.php"> <img src="../img/retornar.png" width="30"> </a></td>

		</tr>


		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>

			<td class="texto3" align="center"><font size="4">Administrador</font></td>
			<td><input type="text" name="usuario" id="usuario" size="15" maxlength="20" required="true" placeholder="Digite su usuario" class="texto"> </td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr> 

			<td class="texto3" align="center"><font size="4">Clave</font></td>
			<td><input type="password" name="clave" id="clave" size="15" maxlength="40" required="true" placeholder="Digite su clave" class="texto"> </td>

		</tr>

		

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr> 

			<td class="texto3" align="center"><font size="4">Confirmación</font></td>
			<td><input type="password" name="confirmacion" id="confirmacion" size="15" maxlength="40" required="true" placeholder="Confirme su clave" class="texto"> </td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			<th colspan="2" align="center"><input type="submit" value="Almacenar" class="boton" > </th> 
		</tr> 
		<br> <br>
		<tr>
			<td colspan="2">&nbsp;</td>
		</tr>
		<tr> 
			<th colspan="2" align="center"><input type="reset" value="Restablecer" class="boton" > </th>
		</tr>
		<tr>
			<td colspan="2">&nbsp;</td>
		</tr>
	</table>
</form>

 <br>

 <table width="700" border="0" align="center" class="tabla usuario">

	<tr>

		<th colspan="4" class="titulo usuario2">LISTA GENERAL DE ADMINISTRADORES </th>

	</tr>

	<tr> 

		<td colspan="4">&nbsp;</td>
	</tr>

	<tr>

		<td class="campo texto3" width="100" align="center">Administrador</td>
		<td class="campo texto3" width="300" align="center">Clave</td>
		<td></td>
		<td></td>

	</tr>

	<tr> 

		<td colspan="4">&nbsp;</td>
	</tr>

	<?php 

	 foreach ($aUsuario as $lUsuario) { ?>

	<tr> 

	<td width="200" class="campo" align="center"> &nbsp; <?php echo $lUsuario -> usuario;?> </td>
	<td width="400" class="campo"align="center" > <?php echo $lUsuario -> clave; ?> </td>
	<td width="50"><a href="../control/facade.php?opc=144&usuario=<?php echo $lUsuario -> usuario?>" onClick="return confirm(' ¿Seguro de Eliminar este Administrador?')" title="Eliminar"> <img src="../img/delete.png" width="35"> </a></td>

	<td width="50"> <a href="../control/facade.php?opc=160&usuario=<?php echo $lUsuario-> usuario;?>"> <img src="../img/edit.png" width="32"> </a> </td>

	</tr>
	<?php  } ?>
</table>

 <table width="700" border="0" align="center" class="tabla usuario">

	<tr>
		<th colspan="4" class="titulo usuario2">LISTA GENERAL DE USUARIOS  </th>
	</tr>
<br> 
	<tr> 
		<td colspan="4">&nbsp;</td>
	</tr>

	<tr>
		
		<td class="campo texto3" width="250" align="center">Usuario</td>
		<td class="campo texto3" width="250" align="center">Clave</td>
		<td class="campo texto3" width="250" align="center">Cédula</td>
		<td></td>
		<td></td>
	</tr>

	<tr> 

		<td colspan="4">&nbsp;</td>
	</tr>

	<?php //FOREACH FUERA DE LUGAR

	 foreach ($aUsuarioing as $lUsuarioing) { ?>

	<tr> 	<td width="200" class="campo" align="center"> &nbsp; <?php echo $lUsuarioing -> usuarioing;?> </td>
	<td width="400" class="campo"align="center" > &nbsp; <?php echo $lUsuarioing -> claveing; ?> </td>
	<td width="200" class="campo" align="center"> &nbsp; <?php echo $lUsuarioing -> cedula;?> </td>

	<td width="50"><a href="../control/facade.php?opc=154&usuarioing=<?php echo $lUsuarioing -> usuarioing?>" onClick="return confirm(' ¿Seguro de Eliminar este Usuario?')" title="Eliminar"> <img src="../img/delete.png" width="35"> </a></td>

	<td width="50"> <a href="../control/facade.php?opc=179&usuarioing=<?php echo $lUsuarioing-> usuarioing;?>"> <img src="../img/edit.png" width="32"> </a> </td>

	</tr>
	<?php  } ?>
</table>

<?php 

 }

else {
  echo "<script type='text/javascript'> alert('Ingreso Incorrecto'); pagina = '../vista/acceso.php'; tiempo= 10; ubicacion = '_self'; setTimeout('open(pagina, ubicacion)', tiempo); </script>";
}

?>
</body>
</html>

