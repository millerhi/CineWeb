<?php @session_start();?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>
<body >
<?php if(isset($_SESSION["user"])) ?>
	
	<section class="ingreso izquierda titulo ">

						<ul>
	
 						<p class="borde " > Bienvenidos a CineWeb  </p> 
 						<h4 class="borde">Regístrate para disfrutar de toda la informacion disponible</h4>
				
						</ul>
</section>


	<form method="post" action="../control/facade.php?opc=152" onsubmit="return validarusuario()">
	 

	<table border="0" width="530" align="center" class="tabla usuario medio2">

		<tr>

			  <th colspan="2" class="titulo usuario2">&nbsp;REGISTRO DE USUARIOS CINEWEB&nbsp; </font> </th>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>


		<tr>
				<td class="texto3" align="center"><font size="4">Cédula</font></td>
			<td><input type="text" name="cedula" id="cedula" size="15" maxlength="10" required="true" placeholder="Digite su Cédula" class="texto"> </td>

		</tr>

		

		<tr>

			<td class="texto3" align="center"><font size="4">Usuario</font></td>
			<td><input type="text" name="usuarioing" id="usuarioing" size="15" maxlength="20" required="true" placeholder="Digite su usuario" class="texto"> </td>

		</tr>
		

		<tr> 

			<td class="texto3" align="center"><font size="4">Clave</font></td>
			<td><input type="password" name="claveing" id="claveing" size="15" maxlength="40" required="true" placeholder="Digite su clave" class="texto"> </td>

		</tr>

		<tr> 

			<td class="texto3" align="center"><font size="4">Confirmación</font></td>
			<td><input type="password" name="confirmacion" id="confirmacion" size="15" maxlength="40" required="true" placeholder="Confirme su clave" class="texto"> </td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			<th colspan="2" align="center"><input type="submit" value="Almacenar" class="boton" > </th> 
		</tr> 
		<br> <br>
		<tr>
			<td colspan="2">&nbsp;</td>
		</tr>
		<tr> 
			<th colspan="2" align="center"><input type="reset" value="Restablecer" class="boton" > </th>
		</tr>
		<tr>
			<td colspan="2">&nbsp;</td>
		</tr>
	</table>
<br>

	<p class="click2 "> ¿Ya tienes una cuenta? Dale click al icono <a href="../vista/ingreso.php"> <img src="../img/cuenta.ico" width="40"  align="center"></a> </p> 
				
</form>
</body>
</html>
