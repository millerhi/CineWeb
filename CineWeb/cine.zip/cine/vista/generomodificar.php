<?php @session_start();?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>
<body >
	<?php if(isset($_SESSION["user"])) {?>

	<br> <br> 

	<table border="0" width="1200" align="center">

		<tr>

			<th align="center" class="sombra2">  <font size="7" class="eltitu" > ¡Películas Online! </font>   </th>


		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>
		


	</table>

	<form method="post" action="../control/facade.php?opc=46" onsubmit="return validargenero()">
	<br> <br> 

	<?php foreach ($aGenero as $lGenero) { ?>

	<table border="0" width="600" align="center" class="tabla usuario">

		<tr>

			<th colspan="2"><font size="5" class="titulo usuario2">&nbsp;Administración de Géneros&nbsp; </font> </th>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;<a href="../control/facade.php?opc=43"> <img src="../img/retornar.png" width="30"></td>

		</tr>

		

		<tr>

			<td class="campo">Código</td>
			<td><input type="text" name="codigogenero" id="codigogenero" size="15" maxlength="10" required="true" placeholder="Digite Código" class="texto" value="<?php echo $lGenero -> codigogenero;?>" readonly> </td>

		</tr>

		<tr> 

			<td class="campo" >Nombre</td>
			<td><input type="text" name="nombre" id="nombre" size="40" maxlength="40" required="true" placeholder="Digite Nombre" class="texto" value="<?php echo $lGenero -> nombre;?>"> </td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>

			<th colspan="2"><input type="submit" value="Almacenar" class="boton" >&nbsp; <input type="reset" value="Restablecer" class="boton" > </th>
		</tr>
		

	</table>

	<?php } ?>
	<?php 
}
else {
  echo "<script type='text/javascript'> alert('Ingreso Incorrecto'); pagina = '../vista/acceso.php'; tiempo= 10; ubicacion = '_self'; setTimeout('open(pagina, ubicacion)', tiempo); </script>";
}

?>

</form>
</body>
</html>