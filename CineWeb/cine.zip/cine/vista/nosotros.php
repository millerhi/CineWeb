<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>
<body>


 	

<section id="nosotros">



	 <ul>

	 	<a href="../control/facade.php?opc=158"> <img src="../img/retornar.png" width="45" align="center"></a>
			<p class="eltitu1 ">Objetivo géneral</p>
			<p class="eltitu2"> Realizar un entorno web que permita a uno o más usuarios ver que 
películas están disponibles a través de una cartelera virtual.</p>
			

					<p class="eltitu1">Misión</p>
					<p class="eltitu2">La misión de CineWeb es brindar una experiencia muy cómoda para todos los usuarios mientras visualizan todas las películas disponibles en nuestro entorno web. Queremos que nuestros usuarios se sientan seguros y tengan un buen agrado al visitar nuestro entorno web.</p>
				

						<p class="eltitu1" >Visión</p>
						<p class="eltitu2"> En los próximos años CineWeb se convertirá en uno de los mejores entornos webs dedicados a promocionar películas disponibles en carteleras de cines reconocidos internacionalmente.</p>
						

</ul>
</section>







</body>
</html>