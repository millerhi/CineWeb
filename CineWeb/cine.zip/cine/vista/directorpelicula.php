<?php @session_start();?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>
<body >
	<?php if(isset($_SESSION["user"])) {?>


	<br> <br>
	<form method="post" action="../control/facade.php?opc=102"> 

	<table border="0" width="1200" align="center">

		<tr>

			<th align="center" class="sombra2">  <font size="7" class="eltitu" > ¡Películas Online! </font>   </th>


		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>
		


	</table>
	<br>

	<table width="700" border="0" align="center" class="tabla usuario">
		
<tr>  

	<th colspan="2" class="titulo usuario2">Director Película </th>

</tr>

<tr>

	<td colspan="2">&nbsp; </td>

</tr>

<tr> 

	<td colspan="2">&nbsp; <a href="../vista/menu.php"> <img src="../img/retornar.png" width="35"> </a> </td>

</tr>

<tr>

	<td colspan="2">&nbsp; </td>

</tr>

<tr>
	
<td class="campo">Directores </td>
<td class="campo">Películas </td>


</tr> 

<tr>

	<td>&nbsp;<select name="codigodirector" id="codigodirector">
		<?php foreach ($aDirector as $lDirector) { ?>  
		<option value="<?php echo $lDirector -> codigodirector;?>"> <?php echo $lDirector -> nombre;?> </option>

		<?php } ?>
	</select>
	</td>
	<td >&nbsp;<select name="idpelicula" id="idpelicula">
		<?php foreach ($aPelicula as $lPelicula) { ?>
	<option value="<?php echo $lPelicula -> idpelicula;?>"><?php echo $lPelicula -> titulooriginal;?>
	 &nbsp;/&nbsp; <?php echo $lPelicula -> titulolatino;?>  </option>
	  <?php } ?>

	 </select>
	  </td>

</tr>

	<tr>

		<td colspan="2">&nbsp; </td>
	</tr>

	<tr> 

		<th colspan="2"><input type="submit" name="Almacenar" class="boton">&nbsp;<input type="reset" name="Restablecer" class="boton"> </th>

	</tr>


	</table>

</fomr>

<br> <br> 


 <table width="800" border="0" align="center" class="tabla usuario">
 	
 	<tr>

 		 <th colspan="4" class="titulo usuario2">Listado de Director por película</th>

 		</tr>

 		<tr>

 			<td colspan="4">&nbsp;</td>

 		</tr>

 		<tr>

 			<td class="campo texto4" width="90">ID</td>
 			<td class="campo texto4" width="210">Director</td>
 			<td class="campo texto4" width="300">Película</td>
 			<td class="campo">&nbsp;</td>
 			</tr>

 			<tr> 

 			<td colspan="4">&nbsp;</td>

 			</tr>

 			<?php foreach ($aDirectorpelicula as $lDirectorpelicula) { ?>

 			<tr> 

 			<td class="texto3">&nbsp;<?php echo $lDirectorpelicula -> id;?> </td>
 			<td class="texto3">&nbsp;<?php echo $lDirectorpelicula -> nombre;?></td>
 			<td class="texto3">&nbsp;<?php echo $lDirectorpelicula -> titulooriginal;?> / <?php echo $lDirectorpelicula -> titulolatino;?></td>
 			<td align="center">&nbsp;<a href="../control/facade.php?opc=104&id=<?php echo $lDirectorpelicula -> id;?>" onclick ="return confirm('¿Seguro de Eliminar?')"><img src="../img/delete.png" width="32"></a></td>

 		</tr>


 	<?php } ?>
 </table>
 <?php 
}
else {
  echo "<script type='text/javascript'> alert('Ingreso Incorrecto'); pagina = '../vista/acceso.php'; tiempo= 10; ubicacion = '_self'; setTimeout('open(pagina, ubicacion)', tiempo); </script>";
}
?>
</body>
</html>
