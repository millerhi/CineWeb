<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CINEWEB</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<script type="text/javascript" src="../js/validar.js"></script>
</head>
<body>

	

	<section class="ingreso izquierda titulo">

						<ul>
	
 						<p class="borde sombreado" > Bienvenidos a CineWeb  </p> 
 						<h4 class="borde sombreado">Ingresa y disfruta de toda la información disponible</h4>
				
						</ul>
</section>
	
	<form method="post" action="../control/facade.php?opc=153" onsubmit="return validarusuario()">
	 

	<table border="0" width="440" align="right" class="tabla usuario derecha" >

		<tr>
			<th colspan="2" class="titulo usuario2">&nbsp;INICO DE SESIÓN&nbsp; </font> </th>

		</tr>
		<tr> 
                  <td> <a href="../vista/acceso.php"><img src="../img/tools.png" width="35"></a></td></tr>
		
		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			 </a></td>

		</tr>


		<tr>
			
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>

			<td class="texto3" align="center">Usuario</td>
			<td><input type="text" name="usuarioing" id="usuarioing" size="15" maxlength="20" required="true" placeholder="Digite su usuario" class="texto"> </td>

		</tr>	

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>
		
		<tr> 

			<td class="texto3" align="center">Clave</td>
			<td><input type="password" name="claveing" id="claveing" size="15" maxlength="40" required="true" placeholder="Digite su clave" class="texto"> </td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			<td colspan="2">&nbsp;</td>

		</tr>

		<tr>
			<th colspan="2" align="center"><input type="submit" value="Almacenar" class="boton" > </th> 
		</tr> 
		<br> <br>
		<tr>
			<td colspan="2">&nbsp;</td>
		</tr>
		<tr> 
			<th colspan="2" align="center"><input type="reset" value="Restablecer" class="boton" > </th>
		</tr>
		
		<tr>
			<td colspan="2">&nbsp;</td>

		</tr> 

	</table>

	<br>

	 <p class="click"> ¿Aún no tienes cuenta? Dale click al icono <a href="../vista/registro.php"> <img src="../img/click.ico" width="40" align="center"></a> </p>
	 



 

</form>

</body>
</html>
